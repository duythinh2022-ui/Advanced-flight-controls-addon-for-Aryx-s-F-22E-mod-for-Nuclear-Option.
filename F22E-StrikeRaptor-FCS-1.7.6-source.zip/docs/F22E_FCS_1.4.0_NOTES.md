# F-22E Strike Raptor FCS 1.4.0 (Nuclear Option)

**Install:** `BepInEx/plugins/` should contain the unmodified `Aryx_F22E_StrikeRaptor_1.0.4.dll` and
`Aryx_F22E_StrikeRaptor_FCS.dll` (1.4.0, about 75 KB). The config is
`BepInEx/config/Aryx_F22E_StrikeRaptor.FCS.cfg`. `ConfigVersion` 4 resets `MaxRollRate` to its new default
(420, now only an absolute ceiling) once. Obsolete keys (`RollRateSpeedRef`, `UnloadAoAAccel`, `UnloadRateKeep`,
`UnloadGAccel`, `AoADamping`) are ignored and can be deleted.

## Changes from your 1.3.0 feedback

### Roll
- **Original-aircraft reference.** I re-derived the stock FlyByWire roll law from the IL. Its roll target is a fixed
  286 °/s (`maxRollAngularVel` 10 × clamp(q̄/q̄corner / `maxRollSpeed`, 0.5, 1)). That clamp always sits at 0.5,
  so the (210/V)² schedule 1.2/1.3 claimed to copy never existed. The P gain is 1.1, blended toward direct stick
  by q̄/q̄corner (corner 140 m/s). I ran that law on the stock airframe (stock ranges and areas, roll TVC on) in a
  pure-roll model. The steady rate comes out as `p = kV` with k = 1.07 °/s per m/s TAS (full deflection), and above
  corner speed as the law's equilibrium `kV(1+4.5r)/(1+1.1·r·kV)`, r = q̄corner/q̄. The fit is within 3 % of the run at
  1 and 6 km.
- **Ceiling** = that stock rate × **1.2 below 120 m/s IAS**, **×1.1 above 170** (`RollRateGainLowIAS/HighIAS`),
  and never more than the airframe can hold. The FCS estimates roll damping online (every aero part with a small
  roll rate added) and the usable roll control moment (flaperons + outer flaperons + ¼ of differential stab). The
  full-deflection steady rate is their ratio, and the ceiling is `RollAuthorityUse` (default **1.0**, your "max
  deflection up to where it stays stable") × that rate.
- **Entry** uses only the authority left after damping at the present rate, never a plan that needs more than
  full deflection. **Stops** use `RollBrakeUse` (0.8) of the authority.
- Measured stability limit in the sim: at 1.0 the wing surfaces sit at 63–98 % steady, β ≤ 2.7°, stop within
  0.5 s, no rebound. At 1.15, β starts growing (3°+) and the surfaces sit at 93–96 %, so 1.0 is where I set it.
- Roll/yaw surfaces (flaperons, outer flaperons, rudders) no longer take part in pitch allocation. Before, they could
  end up fighting each other (flaperons one way, ailerons the other) to squeeze pitch moment out of their stall
  nonlinearity.

| TAS / alt | original a/c (sim) | 1.4 ceiling | 1.4 achieved | wing surfaces steady |
|---|---|---|---|---|
| ~95–115 m/s / 3 km | ~105–125 | authority-limited 128 | 96 | 63 % |
| ~130 / 3 km | ~140 | 146 | 124 | 66 % |
| ~160 / 3 km | ~170 | 172 | 160 | 91 % |
| ~200 / 3 km | ~200 | 203 | 197 | 98 % |
| ~245 / 3 km | ~250 | 243 | 238 (peak) | 85 % |
| ~310 / 3 km | ~285 | 304 | 278–299 | 90 % |

**Honest limit:** at low IAS the original jet had ±10° differential roll TVC. Without it (F-22 pitch-only TVC, as you
asked), full wing deflection gives about 1.3 × TAS °/s. That is roughly stock+20 %, but only at 100 % deflection
and before the flap-roll bias and AoA losses. In the full 6-DOF sim at 95–130 m/s you get about 0.8–0.9 × the
original rate. The 1.2 target would need either full saturation, which is what you wanted gone, or more flaperon
effectiveness. Say if you want me to raise `FlaperonEffectiveness` (1.5 → about 1.9 would cover it).

### Pitch
- **Stab stall protection removed from the pitch axis.** The stabilator pitch model is now monotone in the normal
  direction: wherever the real curve reverses (stab post-stall), it is held flat. The FCS never deflects a stalled
  stab "backwards" for pitch and never holds it deflected for a moment it wouldn't normally make. After a
  high-AoA release the stabs now sit at about 0 to −15° instead of +20…+28°. Roll and yaw still use the real curve.
- **Post-stall:** when the stabs have no usable pitch range left (`stabPitchFrac` → 0), the allocator's pitch weight
  drops from 8–15 to 1, roll/yaw rise to 1.5/2.5, and differential-stab cost drops 50×. The stabs are freed for
  roll/yaw and TVC carries pitch.
- **Consequence you should know about:** above about 50° AoA at low speed, pitch authority is now TVC only. In the
  sim, 52° commanded at 86 m/s holds about 49–51° (was ±0.4), MPO full aft at 90 m/s tops out at 68° (was 146°),
  and protection recovery from 72° peaks at −12 to −15 °/s (was −35) though it still recovers to 19°. The 48 °/s
  recovery you specified is not physically available without using stab reversal.
- **Trim / sustaining:** TVC is now the cheapest pitch effector (cost 5e-5, stab symmetric cost 0.004 on top of its
  own). The honest part: your airframe is **not** relaxed-stable in NO's model. The pitch moment with surfaces
  neutral falls by about 11 kNm per degree of AoA at 100 m/s (−198 kNm at 20°), so it is statically stable with
  about 0.6 m of margin, and fuel moves the CG only about 4 cm. Holding AoA therefore needs a real moment. At
  20° / 160 m/s, full TVC (10°) is not enough, so the stabs carry about 9–10°. I tried pushing the stab cost higher
  (0.05–0.3). It only moved the stabs about 1° and cost AoA accuracy (−1.3 to −1.8° errors), so I left it at 0.004
  (`StabilatorTrimCost`).
- **Unload (easing the stick)** is rewritten as you described. The target is the pitch rate the aircraft will
  *sustain* at the new AoA: present flight-path rate plus the lift change between the two AoAs from the envelope
  sweep. It is reached by a smooth deceleration (`UnloadDecel` 20 °/s², jerk-limited), plus a small AoA-error term
  that firms up near the end. If AoA *rises* during the decel, the target drops by 1.5 × AoA rate
  (`UnloadRiseGain`), down to zero at most, and the deceleration limit is raised. Sim, easing 50° → 20° at 105 m/s:
  q 14 → about 1 in 0.8 s, then climbs smoothly back to 10 as AoA settles. No stop-and-wait plateau, no reversal.
- **Stick-oppose override / nose shoves:** while the stick is pulled in AoA/G mode, the FCS never commands a
  nose-down pitch rate. The exceptions are protection, which is scaled by (1 − stick), and a real load-limit
  exceedance, which is also scaled by (1 − stick). This covers AoA overshoot corrections and the kinematic limiters,
  which could push the nose down when the flight path was falling. Mirror logic applies for pushes. Sim: full aft
  stick holds q ≥ 0 in every pull test. Protection from 67° at stick 0 / 0.5 / 1 gives q −12 / −6.6 / 0.
- Fixed a trajectory bug. When a limit moved back past the commanded pitch rate, the command could run on past
  its target: q reached −65 °/s in a 190 m/s reversal. Now |q| ≤ 49.

## Sim regression (6-DOF bench, flap devices, +8 % thrust, −11.5 % dragArea)
| Test | 1.4.0 |
|---|---|
| Neutral stick 200 m/s | q 0.0 |
| Full aft 230 / 300 m/s | 9.10 / 9.35 g |
| Full aft 90 m/s | AoA 61.1 (64.9 in 1.3; less stab authority post-stall), q ≤ 47.7 |
| Full forward 230 m/s | −3.71 g |
| AoA hold 16–39° | ±0.2° (52° at 86 m/s: −1 to −3°, see above) |
| Stick reversal 110 / 190 / 300 m/s | \|q\| ≤ 48.9 / 49.0 / 33 |
| Rolling pull 250–400 m/s | ≤ 9.51 g |
| Full roll at 22° AoA, 150 m/s | p 117, β −10 on the stop (as 1.3) |
| Ground at standstill | direct surfaces + nozzles |
| 60 s random stress | no NaN, 0.3 ms per step. Load exceedances at 300–400 m/s only right after the test flips MPO → assist-on while above 9.5 g, and at 450+ m/s where the bench has no transonic aero. |

Telemetry adds `pMax, pStockRef, pFull, stabPitchFrac`. If a CSV from your next flight shows the roll ceiling
(pMax) sitting well below pStockRef at low speed, that is the authority limit described above.
