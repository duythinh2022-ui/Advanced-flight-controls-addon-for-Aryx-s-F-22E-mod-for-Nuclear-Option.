# F-22E Strike Raptor FCS 1.3.0 (Nuclear Option)

**Install:** `BepInEx/plugins/` should contain the unmodified `Aryx_F22E_StrikeRaptor_1.0.4.dll` and
`Aryx_F22E_StrikeRaptor_FCS.dll` (1.3.0, about 70 KB). This file replaces the 1.2.x companion. The config is
`BepInEx/config/Aryx_F22E_StrikeRaptor.FCS.cfg`. On first load, three values whose defaults changed
(SideslipGain, FlaperonEffectiveness, StabilatorEffectiveness) are reset to the new defaults once, through a
`ConfigVersion` key. New keys are added automatically.

## Changes from your 1.2.1 feedback

| Complaint | What changed |
|---|---|
| Yaw rate too high / is it capped at 65 | The body yaw command was, and still is, capped at 65 °/s. Now it is also capped at `0.45 × measured yaw authority` (20–65 °/s), so the yaw axis can always stop again. In the sim, measured \|r\| never went above 51 °/s. |
| Roll uses max deflection, slow to stop, pitch coupling | The velocity-vector roll command now follows a jerk-limited trajectory. It accelerates at up to 60 % of measured authority (both axes it maps into), with at most 720 °/s². The acceleration is fed forward to the inner loop. Stops brake on a sqrt curve, may lead the yaw axis by 1.3×, and have almost no overshoot. Pitch has priority in allocation (weight 8–15, was 4–10). Differential stab (roll use) costs 5× more, so roll comes from the wing first. |
| Roll wobble | Rudder β regulation 2.5 → 2.0 /s, with a 0.12 s smoothing on the regulation term. The β guard is smoothed. A yaw-saturation monitor (allocator shortfall) backs the roll command off before sideslip builds, which removes a guard/roll limit cycle at 20–30° AoA. |
| Effectiveness bump | Flaperon/aileron 1.40 → **1.50**, stabilator 1.25 → **1.30** (lifting area; travel unchanged). |
| Stabs "stuck" deflected after a high-AoA release | Checked. At 55–62° AoA in the zero-rate hold, the stabs sit at +20…+28° (the pull direction). That puts their own local AoA at ~30°, near their C_L peak. Past the stall that is the direction that gives the most **nose-down** moment, so it is the reversal logic you asked for. They come back as AoA falls below ~35°. The symmetric flaperon/rudder "pitch help" they were fighting is gone. |
| AoA unload stopped at zero rate and waited | AoA is now walked down on a sqrt profile. The pitch rate is eased down but never below **30 % of the present flight-path rate** (`UnloadRateKeep`) and never reversed. It eases back up to the flight-path rate as the target is reached. With no flight-path rate left (60° zero-rate hold), the floor is 0, so it keeps holding zero rate. |
| Rudder roll aid too strong; V-tail roll at high AoA | Rudders fade out from **35° to 50° AoA** (`RudderFadeStartAoA/EndAoA`). See the numbers below. |
| Stabs trimming at moderate AoA | Nozzles now share trim with the stabs (TVC trim cost equals stab cost; it was 5× higher). Flaperons, outer flaperons and rudders are left/right pairs, and symmetric use of a pair is heavily penalised, so they are never used as pitch trimmers. |
| Flaps full down post-stall / scheduled | Both devices are taken over (see below). |
| Outer flaperon load relief active post-stall | Now keyed to load factor: 0 below 3 g, up to 9.6° TE-up at 9 g. It fades out between 16° and 24° AoA and slews at 8 °/s. |
| AoA command not accurate (> ±1°) | AoA law is now a dynamic inversion of `α̇ = q − γ̇` using measured flight-path rate, with an integrator near the target. The limiter capture sits 0.2° past the command. |
| AoA protection override | Recovery is now an absolute pitch rate: stick neutral gives up to 48 °/s nose-down, half pull gives half, full pull gives **zero pitch rate**. Before, full pull still let the nose follow a falling flight path. |
| Thrust +8 % | Per engine, `staticThrust` goes from 120 to 129.6 kN and afterburner `thrust` from 40 to 43.2 kN. The max-AB total goes from 160 to 172.8 kN (×1.08). Fuel flow is untouched: engine burn depends on spool, and AB burn is `afterburnerAmount × fuelConsumption`. The FCS reads live thrust, so the T/W-based pitch budget follows automatically. |
| Straight-line drag −10 % | Parasitic `dragArea` ×0.885 on every part. Parasitic drag is 83–93 % of straight-line drag, so the total drops 9.6 % at 250 m/s / 8 km and 10.7 % at 300 m/s / 1 km. |
| Surfaces dead at 0 m/s on the ground | Weight-on-wheels now uses the stock direct mixing. Each surface is `pitch·pitchRange + roll·rollRange + yaw·yawRange` and the nozzles follow pitch stick, independent of airspeed. |

Thrust, drag, pitch-only TVC, servo ×1.3 and effectiveness apply to every F-22E, AI included. The FCS and flap
takeover apply to the player's aircraft only.

## Flaps (HighLiftDevice + AryxAlphaResponder takeover)
Flap_* > FlapAOADrive (AlphaResponder) > HighLiftServo (HighLiftDevice) > FlapServo (lift normal). All three
rotations add up to the flaperon's aerodynamic angle. While the FCS flies the aircraft, both scripts are skipped
and the FCS drives them:
- **Baseline kept:** the high-lift part uses the mod's own schedule (out below 100 m/s, in above 130 m/s,
  15° plus slats plus 4 m² on WingRear, 1/s slew), plus up to 8° of maneuver flap.
- **Lift-demand gated:** there is flap only when the wing is asked for positive lift (AoA 0→4° and n 0.2→0.7 g ramps).
  Inverted pushing, negative AoA and unloaded vertical flight retract them.
- **Stall capped:** total bias ≤ flaperon C_L-peak local AoA (from the effector model) − 5° − the TE-down control
  travel the roll axis may need, whichever is larger: what it is using now or 12° × |roll stick|. That is the
  roll bias: full roll stick at high flap retracts the bias so the flaperon keeps its roll range.
- High-lift part and maneuver flap fade out between 20° and 30° AoA (wing C_L peak is 35°).

Sim snapshots: 112 m/s at 13° AoA gives 14.7° bias (stall-capped); the same condition with full roll gives 0.1°; 32° and 58° AoA give 0;
pushing to −9° gives 0; 215 m/s at 9.5° / 4 g gives 7.6° bias and 1.8° relief. On the ground at a standstill it gives takeoff flaps.

## Rudder fade: the numbers behind it
The NO airframe model has no tail blanking. Rudder pair at 10° (yaw right), 100 m/s, from the game's aero
equations on this geometry:

| AoA | 0 | 20 | 30 | 40 | 50 | 55 | 60 | 65 | 70 |
|---|---|---|---|---|---|---|---|---|---|
| yaw (kNm) | 41.1 | 38.8 | 35.8 | 31.6 | 25.9 | 21.5 | 15.6 | 8.9 | 3.2 |
| roll/yaw | −0.75 | −0.74 | −0.77 | −0.82 | −0.93 | −1.03 | −1.22 | −1.72 | −3.73 |

The adverse roll of the canted rudders exceeds their yaw power from about 55°. The fade (35→50°) follows the
real F-22's blanking regime rather than this model. It costs high-AoA yaw authority: at 45–55° the coupled axis
now reaches about 20 °/s of yaw, where 1.2 reached about 35–40 °/s. If you want that back, raise
`RudderFadeEndAoA`, for example to 60.

## Sim results (same bench as 1.2, now with the flap devices, +8 % thrust and −11.5 % dragArea modelled)
| Test | Result |
|---|---|
| Neutral stick 200 m/s | q 0.0 |
| Full aft 90 m/s | AoA 64.9, q ≤ 47.8 |
| Full aft 230 / 300 m/s | 9.10 / 9.32 g |
| Full forward 230 m/s | −3.71 g (5 % over, as before) |
| AoA hold (5 cases, 16–52°, speed changing, roll disturbance) | error −0.37…+0.20°, most within ±0.2° |
| Ease 50° → 20° at 105 m/s | q 14 → 4 over 0.5 s, holds ~4 while AoA bleeds about 10 °/s, eases back to 11.6 at 19.4°, no overshoot |
| Protection from 78° at stick 0 / 0.5 / 1 | peak q −35 / −23 / 0, full pull holds the attitude |
| Stick reversal 110 / 190 / 300 m/s | \|q\| ≤ 48.9 / 49.1 / 35 |
| Full roll 220 m/s | 280 °/s, stop 280 → 0 in about 0.5 s, overshoot −12 °/s, β within ±4.4° |
| Full roll at 22° AoA, 150 m/s | p 102, r 45, stop to 22 °/s in 0.5 s; β −10.9° transient on the stop (yaw axis servo/authority limited) |
| Full roll at 29° AoA, 120 m/s | β within ±2.8°, stop in about 0.5 s |
| Pedal 220 m/s | β −15 to −16°, no roll |
| Ground at 0 m/s, full aft / right / half pedal | stabs 10 / 30, flaperons ∓11, ailerons ∓17, rudders ±14, nozzles 10° |
| 60 s random stress | no NaN, 0.26 ms per step. Load exceedances (up to 13.2 g in MPO, −4.4 g) occur only above 450 m/s (M1.4+), where the bench has no transonic model and the game may never go. |

**Not verified:** anything in the real game. Known sim-vs-game gaps: rigid joints instead of FixedJoints,
point-mass inertia, no transonic aero, and flap device IDs matched by hierarchy (checked against the bundle).
At 20–25° AoA a full-rate roll stop can still build about 10° of sideslip, because the yaw axis is limited by
rudder servo rate and authority.
