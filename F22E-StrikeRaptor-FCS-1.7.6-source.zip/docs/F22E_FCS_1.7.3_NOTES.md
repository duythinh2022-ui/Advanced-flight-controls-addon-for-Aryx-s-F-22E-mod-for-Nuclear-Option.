# F-22E Strike Raptor FCS 1.7.3 (Nuclear Option)

1.7.3 is 1.7.2 plus a fix for the hitch in instant roll reversals. It has no config changes. The numbers are from
the 6-DOF bench (3 km, ~4° AoA, full stick one way for 1.5 s, then full stick the other way). None of this has been
flown in game yet.

## Cause
The roll command runs on a shaped trajectory. When braking, its planned deceleration is "0.8 × wing-surface
authority + the roll damping at the present rate". That taper was added in 1.6.2 so a *stop* ends with the surfaces
near neutral. Otherwise they were still at full deflection at zero rate, and the jet rebounded. In a *reversal*,
the same taper applied until the rate crossed zero. Near zero the planned deceleration shrank, the surfaces swung
back toward neutral (120 m/s: from 77 % of travel to 9 %), and then they swung out again for the new roll. The roll
acceleration sagged and surged, and that was the hitch you felt.

## Fix
When the new roll target is on the other side of zero, the braking deceleration is not allowed to drop below 0.6 ×
the roll authority, which is the acceleration the new roll starts with. It is also capped by what the yaw axis can
follow, so high-AoA reversals are unaffected. Stops (target zero) are exactly as before.

| Instant reversal | Roll accel sag → surge around zero, 1.7.2 | **1.7.3** | Time to half the opposite rate, 1.7.2 → 1.7.3 |
|---|---|---|---|
| 90 m/s | 126 → 203 °/s² (38 %) | 168 → 187 (**10 %**) | 0.96 → 0.90 s |
| 120 m/s | 215 → 312 (31 %) | 270 → 289 (**7 %**) | 0.86 → 0.82 s |
| 160 m/s | 316 → 487 (35 %) | 434 → 452 (**4 %**) | 0.78 → 0.74 s |
| 220 m/s | 7 % | 2 % | 0.68 s |
| 300 m/s | 1 % | 1 % | 0.64 s |

- **Floor strength tried:** 0.5, 0.6, 0.7 and 0.85. At 0.85 the 160 m/s hitch is gone completely, but roll spam at
  100–140 m/s then disturbs pitch up to −3.7 °/s. 0.6 keeps roll-spam pitch within −1.1…+1.5 °/s (1.7.2: −0.5…+1.5).
- **The remaining ~10 % at 90 m/s** is the surfaces handing over from braking to the new direction at servo rate.
- **Stops, overshoot and roll jerk** are unchanged at all speeds (90–560 m/s). Nothing else in the regression moved.
- **The stock-performance build** shows the same result: 10 / 7 / 4 / 2 / 1 %.
