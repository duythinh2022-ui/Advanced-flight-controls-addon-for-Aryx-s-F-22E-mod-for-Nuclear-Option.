# F-22E Strike Raptor FCS 1.6.5 (Nuclear Option)

1.6.5 is 1.6.4 plus a wider yaw-rate cap at low IAS. The build also contains the read-only `FcsApi` that the flight
data readout uses to show the commanded AoA / G. Install: replace `Aryx_F22E_StrikeRaptor_FCS.dll`.

## Why the falling leaf only reached ~20 °/s of yaw
The 75 °/s `MaxYawRate` is only an absolute ceiling. Above 15–25° AoA the body yaw rate is also capped at
`YawStopFactor` (0.7) × the measured yaw authority, so the yaw can always be stopped again. The cap never goes below
20 °/s. Yaw authority scales with dynamic pressure, so at falling-leaf speeds the cap sits at its 20 °/s floor.
That was the 20–23 °/s you saw. So the limit is IAS-based in effect, but through measured authority rather than an
IAS table.

## Change
New `LowIasYawBoost` = 1.35 widens that cap, and its 20 °/s floor, by 35 % below 120 m/s IAS, fading back to 1.0 by
180 m/s. Above 180 m/s nothing changes.

| 6-DOF bench | 1.6.4 | 1.6.5 |
|---|---|---|
| Falling leaf (full aft, full pedal left/right every 2 s), entered at 90 / 120 m/s, AoA 63–68° | \|r\| max 19.1 / 20.6 °/s | **24.2 / 26.1 °/s** |
| Pedal at 55° AoA, 83 → 67 m/s | r ≤ 19.8 °/s, β ≤ 1.8° | **r ≤ 25.9 °/s**, β ≤ 2.7° |
| Stick roll at 45° AoA, 92 → 73 m/s | r ≤ 20.1 °/s, β ≤ 1.0° | **r ≤ 26.9 °/s**, β ≤ 1.5° |
| Full roll at 29° AoA, 120 m/s | β −7.7…+5.1° | β −6.5…+5.6° |
| Everything above 180 m/s IAS, pitch tests, stress | — | unchanged |

**Trade-off:** the yaw stops take a little longer at low speed, as you accepted. Sideslip during these manoeuvres
grows by up to about 1°. In the falling leaf itself the sideslip after pedal release was smaller than before.
