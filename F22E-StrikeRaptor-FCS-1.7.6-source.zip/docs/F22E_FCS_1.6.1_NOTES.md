# F-22E Strike Raptor FCS 1.6.1 (Nuclear Option)

1.6.1 is 1.6.0 plus a rudder / yaw-axis fix. Install: replace `Aryx_F22E_StrikeRaptor_FCS.dll` (83 KB) next to the
unmodified 1.0.4 DLL. Two new config keys are added with their defaults. Nothing is migrated.

## What was wrong
With the FCS rolling about the velocity vector, the rudders have to supply the body yaw rate `r = p·sin(AoA)`. At
3° AoA and 130 °/s that is about 8 °/s, and it flips sign whenever AoA crosses zero (inverted, or unloaded).

The canted rudders also make roll: about −0.75 kNm of roll per kNm of yaw. Converted to angular acceleration, that
is roughly 3–4 °/s² of roll per °/s² of yaw. The allocator weighted yaw and roll errors equally below 20° AoA, and the
roll demand is far larger, so it made a biased choice:
- **When the needed yaw opposed the roll**, it mostly refused it. In a right roll at 140 m/s, the yaw demand was
  +15…+32 °/s² and the rudders delivered +2…+3. Sideslip built to +3°.
- **When the needed yaw helped the roll**, it used the rudders freely, up to full travel. Once AoA went negative in the
  roll, they swung to −28°. As a result, the yaw rate lagged, then overshot, then reversed.

The wing surfaces' adverse yaw in this model is small (about 1–2 °/s²), so it was not the cause.

The yaw-rate feed-forward (the rate of change of the yaw command) also slammed the rudders at every roll reversal at
low speed, where the rudders are weak.

## Changes
| | 1.6.0 | 1.6.1 | Config |
|---|---|---|---|
| Yaw weight in the allocator, below ~20° AoA | 1 (same as roll) | **8** (post-stall stays ≥ 2.5) | `YawAxisPriority` |
| Yaw-rate feed-forward | 100 % | **50 % below 200 m/s IAS**, blending to 100 % at 300 m/s | `YawRateFeedForward` |
| Load-limiter lead while rolling | 0.15 s | 0.15 s + up to **0.2 s** at ≥ 150 °/s roll (see below) | — |

## Sim results (6-DOF bench, 4 km, ~3° AoA, 1.6.0 → 1.6.1)
Roll spam is full stick ±, reversed every 0.6 s. Reversals count how many times the rudder changes direction over 3.6 s.

| TAS | Rudder travel (spam) | Rudder reversals | Sideslip (spam) | Yaw-rate tracking error | Rudder in one full roll |
|---|---|---|---|---|---|
| 100 m/s | ±28 (full) → **−14…+16** | 17 → 13 | −2.0…+3.8 → **−0.4…+0.9°** | 12.1 → **2.1 °/s** | −19…+21 → −15…+16 |
| 140 | −17…+13 → **−9…+8** | 29 → **7** | −1.5…+2.5 → **−0.2…+0.9°** | 7.4 → **2.5** | −28…+21 → **−12…+8** |
| 180 | −8…+4 → −8…+5 | 24 → **11** | −0.4…+2.3 → **0…+0.7°** | 7.3 → **2.7** | −26…+15 → **−10…+5** |
| 230 | −7…+12 → **−6…+4** | 15 → **7** | −3.9…+0.4 → **−0.1…+0.4°** | 12.1 → **2.6** | −9…+4 → −7…+3 |
| 300 | −5…+3 → −4…+3 | 7 → 6 | ±0.5° | 2.6 → 1.7 | −17…+2 → **−6…+1** |
| 380 | −9…+2 → **−4…+2** | 5 → 5 | −0.3…+1.6 → ±0.5° | 7.8 → **2.2** | −14…+3 → **−5…0** |
| 450 | −4…+1 → −3…+1 | 5 → 2 | ±0.6° | 3.3 → 2.1 | −7…0 → −5…0 |

At 140 m/s spam the rudders now follow a smooth ±8° swing in phase with `p·sin(AoA)`, with no hunting.

Roll performance is unchanged. Steady roll at 3 km: 117 / 153 / 199 / 237 / 258 °/s at 80–220 m/s TAS. At 300 m/s
TAS it went from 244 to **295 °/s**; the uncoordinated roll there used to cost pitch (q −7.9 → −0.8 °/s). Spam roll rate
at 100 m/s went from −92…+86 to −86…+80 °/s, where the allocator now spends a little roll authority on coordination.

Other checks:
| Test | 1.6.0 | 1.6.1 |
|---|---|---|
| 230 m/s straight roll, β | −0.5…+1.1° | −1.0…+0.7°, r −11 → −2.4 °/s |
| Steady full roll 80–130 m/s TAS, β | −1.0…+2.7° | −2.0…+1.1° (50 % feed-forward costs about 1° at the lowest speed) |
| Full roll at 22° AoA, 150 m/s | β −11…+10 | −11…+11 (unchanged, yaw-authority limited) |
| Full roll at 29° AoA, 120 m/s | β −6.5…+6.6 | **−6.2…+4.6** |
| AoA hold after a roll (5 cases) | overshoot ≤ 0.39° | ≤ 0.38° |
| Pedal at 236 m/s | β −13.6 | −14.2 |
| Pitch / protection / MPO / unload tests | — | unchanged within 0.5° / 0.5 °/s |
| 60 s random stress | no NaN | no NaN, 0.24 ms per step |

## Rolling pulls: side effect found and fixed
With the rolls now coordinated, the sideslip that used to bleed off some load in rolling pulls was gone, and the
overshoots got worse. In the 60 s random stress run at about 415 m/s, the peak went from 10.17 to 10.36 g. So the
load limiter now looks further ahead while rolling: its prediction lead goes from 0.15 s to 0.35 s at 150 °/s of
roll or more. This is a transient lead only, so steady load is unchanged (the 1-axis pulls are identical).

| Rolling pull (limit 9.5 g) | 1.6.0 | 1.6.1 |
|---|---|---|
| 250 m/s, full aft + full roll | 9.48 | **9.44** |
| 400 m/s, full aft + full roll | 9.83 | **9.57** |
| Stress run, ~415 m/s | 10.17 | **9.80** |
| 400 m/s rolling pull, MPO | 12.12 | **11.60** |
| 480 / 560 m/s rolling pull | 8.61 / 9.68 | 8.74 / **8.80** |

The peak roll rate in the 400 m/s pulls is 292 °/s. In 1.6.0 it was 342–352 °/s, but that was rolling with sideslip.

`YawAxisPriority = 1` and `YawRateFeedForward = 1` restore the 1.6.0 rudder behaviour exactly. The limiter lead is
not a config key.

Everything else is as in the 1.6.0 notes.
