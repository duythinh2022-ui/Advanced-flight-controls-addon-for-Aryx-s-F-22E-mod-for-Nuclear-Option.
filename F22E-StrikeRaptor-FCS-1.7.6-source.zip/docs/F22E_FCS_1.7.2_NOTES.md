# F-22E Strike Raptor FCS 1.7.2 (Nuclear Option)

1.7.2 is 1.7.1 with the stabs taking over the pitch trim of low-AoA rolls at all speeds, so the TVC no longer sits
at a negative deflection while you roll. `ConfigVersion` 12 resets `RollNozzleHold` (its meaning changed) and
`StabilatorRollShare` once. There is one new key, `RollNozzleWashout`. All numbers are from the 6-DOF bench, 3 km,
buffed build unless noted. None of this has been flown in game yet.

## What was left in 1.7.1
1.7.1 froze the nozzles during rolls only above ~125–150 m/s IAS. Below that, the frozen nozzles meant the stabs had
to do all the pitch trim during fast roll reversals, and the nose dipped up to −4.9 °/s. So at low IAS the nozzles
still trimmed the roll and swung to −4 to −5°. The stronger stab roll in 1.7.1 made that slightly worse.

## How it works now
- **Below ~150 m/s IAS, washout (new).** The allocator runs twice per step. Pass 1 is the free allocation, in which
  the nozzles catch the roll's pitch-moment change first, because they are the fastest pitch trimmer. The slow
  (sustained) part of their deviation from the pre-roll trim (time constant `RollNozzleWashout`, 0.4 s) is then
  removed, and pass 2 re-solves with the nozzles fixed there. So the stabs, already deflecting for the roll, carry
  the sustained part. Fast reversals still get the nozzles' speed, and the nozzles return to trim within the roll.
- **Stab headroom limit.** The handover backs off when either stab is past 75 % of its travel. At 80 m/s the roll
  alone can take one stab to full travel, and forcing the pitch trim onto it there dipped the nose by −2.3 °/s.
  Whatever the stabs cannot take stays on the nozzles.
- **Above ~150 m/s IAS: the 1.7.1 nozzle hold, unchanged.** It costs no pitch disturbance there.
- **The roll-rate trade you offered.** `StabilatorRollShare` 0.6 → 0.55 leaves the stabs a little more headroom at
  80–100 m/s. That is −4 % / −2 % roll rate, and nothing above 130 m/s.
- It only acts in low-AoA rolls (below 12–20° AoA) with no pitch command. It releases whenever you pull or push.

## Results
| Low-AoA full roll, TVC (nozzles) | pre-roll trim | 1.7.1 during the roll: mean (min) | **1.7.2 mean (min)** |
|---|---|---|---|
| 80 m/s TAS | +3.0° | −4.3° (−5.3) | **+0.7° (−1.3)** |
| 100 m/s | +4.0° | −3.8° (−4.6) | **+3.0° (+1.5)** |
| 130 m/s | +2.0° | −3.2° (−5.1) | **+2.1° (+1.2)** |
| 170 m/s | +1.5° | +0.6…+1.3° | **+1.5° (+1.5)** |
| 220 m/s | +0.5° | +0.03…+0.35° | **+0.8° (+0.7)** |

At 80 m/s the stabs run out of travel mid-roll, so the nozzles still give up about 2° there. It is a brief minimum,
not a sustained negative deflection.

| Pitch disturbance / roll | 1.7.1 | **1.7.2** |
|---|---|---|
| Steady full roll, pitch rate, 80–220 m/s | −0.9…+0.9 °/s | −0.7…+0.8 °/s |
| Roll spam (full stick ±, every 0.6 s), pitch rate at 100 / 140 / 180 / 230 m/s | −0.3…+0.9 / −0.6…+0.6 / −0.9…+0.5 / −1.5…+0.6 | −0.5…+1.5 / −1.1…+0.2 / −0.9…+0.5 / −1.5…+0.6 |
| Steady roll rate 80 / 100 / 130 / 170 m/s | 138 / 174 / 206 / 237 °/s | **132 / 170 / 206 / 238 °/s** |
| Roll stop 90 / 120 / 160 m/s | 0.68 / 0.64 / 0.58 s | 0.68 / 0.64 / 0.58 s |
| Roll jerk per °/s of rate, 90 / 120 / 160 m/s | 15 / 15 / 17 | 15 / 16 / 17 |
| AoA hold after a roll, overshoot | ≤ 0.72° | ≤ 0.76° |
| 60 s random stress, max pitch rate (budget 48) | 47.8 | 48.0, no NaN |

Stock-performance build: TVC during the roll is +1.1 / +3.1 / +2.1 / +1.5 / +0.7° (min −0.9° at 80 m/s). Roll rate
is 129 / 165 / 203 / 234 °/s. Roll-spam pitch at 100 m/s is −0.6…+2.2 °/s.

## What I tried and did not keep
| Approach | Why not |
|---|---|
| Freeze the nozzles at all speeds (1.7.1 hold extended down) | Nose dip −4.4…−4.9 °/s in roll reversals at 100 m/s |
| Anchor the nozzles to trim with a cost term | Same: it also blocks the fast transients (−2.7…−5.0 °/s) |
| Stabs do less of the roll (`StabilatorRollCost` 3e-3…3e-2) with the washout | Reversal dips got worse (−4…−6 °/s) |
| Washout without the headroom limit | −2.3 °/s nose dip in the steady 80 m/s roll (stab at −30°) |
| Roll share 0.5 | −9 % roll rate at 80 m/s for no further TVC gain |

## Config
| Key | 1.7.1 | 1.7.2 |
|---|---|---|
| `RollNozzleHold` | 0.05 (nozzle move cost above ~150 m/s IAS) | **1** (0–1 strength of the whole stab takeover; 0 = nozzles trim the roll alone). Reset once. |
| `RollNozzleWashout` | — | **0.4 s** (new; lower = the stabs take over sooner) |
| `StabilatorRollShare` | 0.6 | **0.55** (reset once) |

Cost: the allocator runs twice during low-IAS rolls, about +0.02 ms per step on the bench.
