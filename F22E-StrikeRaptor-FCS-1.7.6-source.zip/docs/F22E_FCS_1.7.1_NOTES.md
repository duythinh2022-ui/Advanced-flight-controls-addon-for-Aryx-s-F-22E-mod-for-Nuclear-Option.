# F-22E Strike Raptor FCS 1.7.1 (Nuclear Option)

1.7.1 is 1.7.0 with the stabilators working harder in low-IAS / low-AoA rolls. Both builds (buffed / stock performance)
get it. `ConfigVersion` 11 resets `StabilatorRollCost` and `StabilatorRollShare` once. There is one new key,
`RollNozzleHold`. All numbers are from the 6-DOF bench (buffed build, 3 km); none of this has been flown in game yet.

## Stabs in low-IAS rolls
The roll ceiling below ~160 m/s IAS counts only part of the differential-stab roll moment as usable authority
(`StabilatorRollShare`). The allocator also charged differential stab use more than the wing surfaces
(`StabilatorRollCost`). Sweeping both separately:
- **The cost alone does not raise the roll rate.** It only moves work from the wings to the stabs. At 5e-4 (was 3e-3)
  the wing surfaces sit at ~0.45–0.57 of their travel in a steady roll instead of 0.69–0.95. That leaves them room
  for the stop.
- **The share sets the rate.** At 0.45 → 0.6 the roll rate rises 14–19 % at 80–100 m/s TAS. Beyond 0.7 there is no
  more steady rate (the original-aircraft ×1.2 ceiling and authority take over), only more pitch wobble in fast
  reversals. At share 1.0 the nozzles hit ±10° and roll spam pitches the nose at up to −7.6 °/s. So 0.6 is the value I
  kept, not the maximum I could set.

| Full-stick roll, 3 km | 1.7.0 | **1.7.1** |
|---|---|---|
| Steady roll rate, 80 / 100 / 130 / 170 m/s TAS | 117 / 152 / 200 / 238 °/s | **138 / 174 / 206 / 237 °/s** |
| Wing-surface travel used in steady roll, 80 / 100 / 130 m/s | 0.69 / 0.86 / 0.95 | **0.45 / 0.57 / 0.52** |
| Sideslip, 80–100 m/s | −2.0…+1.2° | −2.1…+1.3° |
| Roll stop 90 / 120 / 160 m/s (from the higher rate) | 0.64 / 0.60 / 0.60 s | 0.68 / 0.64 / 0.58 s |
| Roll jerk per °/s of rate (roll-stop test) | 14 / 15 / 16 | 15 / 15 / 17 |
| Roll step at 140 m/s, time to 63 % | 0.50 s | 0.50 s |
| Roll spam, pitch rate disturbance, 100 / 140 m/s | −0.3…+0.6 / −0.5…+0.4 °/s | −0.3…+0.9 / −0.6…+0.6 °/s |

The stops take 0.04 s longer at 90–120 m/s only because they start from a 20 % higher rate. The jerk per unit of rate
is unchanged, so the roll is not harsher, and the entry is as quick as before.

## Stabs taking the pitch compensation (instead of the nozzles)
New `RollNozzleHold`: during a low-AoA roll with no pitch command, the nozzles are made expensive to move, so the stabs
(already deflecting for the roll) absorb the roll surfaces' pitch-moment change. It releases whenever the pilot
commands pitch. In an ungated first version, the random-stick stress test reached −54 °/s against the 48 °/s budget.

**It only works above ~125–150 m/s IAS.** Below that, the stabs are busy with the roll and cannot also trim pitch as
fast as the nozzles. At 100 m/s TAS, roll spam then dips the nose at −3.8 (hold 0.02) to −4.9 °/s (hold 0.05), against
−0.3 °/s with the nozzles helping. I also tried gating the hold off while the roll accelerates. That removes its effect
entirely, because the pitch moment appears during the roll entry. At ≥180 m/s TAS the hold costs no pitch at all.
So it fades in from 125 to 150 m/s IAS:

| Low-AoA roll, nozzle swing | 1.7.0 | **1.7.1** | pitch rate |
|---|---|---|---|
| 80 / 100 / 130 m/s TAS (IAS < 125) | −4.3 / −4.0 / −4.3° | −5.3 / −4.6 / −5.1° (nozzles still trim; the stronger roll adds pitch moment) | ≤ ±0.9 °/s both |
| 170 m/s TAS (IAS ~146) | −3.3° | **+0.6…+1.3°** (the stabs take it: −2.2° symmetric) | same |
| 220 m/s TAS | −2.1° | **+0.03…+0.35°** | same |

So the answer to "can the stabs compensate": yes where they have the authority and speed to spare (≥150 m/s IAS).
Below that, letting the nozzles do it gives the steadier nose, and I kept the pitch steady.

## Regression
| Test | 1.7.0 | 1.7.1 |
|---|---|---|
| AoA hold after a roll, 5 cases, overshoot | 0.17–0.64° | 0.17–0.72° |
| Roll at 29° AoA, 120 m/s: rate 0.5 s after release | 29 °/s | 33 °/s (sideslip −6.6…+2.9 → −5.4…+3.0°) |
| Rolling pulls 250 / 400 m/s | 9.46 / 9.66 g | 9.44 / 9.66 g |
| 60 s random stress | q ≤ 47.1, no NaN | q ≤ 47.8, no NaN |
| Pitch, protection, override, MPO, yaw curve, falling leaf | — | unchanged |
| Stock-performance build | — | same pattern: roll 135 / 170 / 203 °/s at 80 / 100 / 130 m/s |

## Config
| Key | 1.7.0 | 1.7.1 |
|---|---|---|
| `StabilatorRollCost` | 3e-3 | **5e-4** (reset once) |
| `StabilatorRollShare` | 0.45 | **0.6** (reset once). 0.7 gives +8 % more rate at 80 m/s for more pitch wobble in reversals. |
| `RollNozzleHold` | — | **0.05** (new; only above ~125–150 m/s IAS, low AoA, no pitch command; 0 = off) |
