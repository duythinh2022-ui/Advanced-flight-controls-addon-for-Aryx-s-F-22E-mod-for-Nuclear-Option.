# F-22E Strike Raptor FCS 1.7.4 (Nuclear Option)

1.7.4 removes the rest of the roll-reversal hitch. No config changes. 6-DOF bench (3 km, ~4° AoA, full stick one
way for 1.5 s, then instantly full stick the other way). Not verified in game yet.

## What was left after 1.7.3
Comparing the commanded with the actual roll acceleration around the zero crossing showed two things:
1. **A step in the plan at zero.** 1.7.3's braking floor (0.6 × roll authority) met the new roll's entry limit
   (0.5 ×) at the crossing, so the command stepped down 15–20 % right at zero (120 m/s: −321 → −271 °/s²).
2. **The damping-assisted braking peak.** Braking was planned as "surfaces + roll damping at the present rate", so the
   commanded deceleration started high and then tapered as the rate fell. The jet lagged that taper, overshot it,
   and the loop pulled the surfaces back. At 120 m/s the wing surfaces went from 79 % of travel down to 23 % and out
   to 53 % again. That was the visible part of the hitch.

## Fix
- **One constant acceleration for a reversal.** When the new target is on the other side of zero, the whole
  reversal is planned at 0.6 × roll authority (capped by what the yaw axis can follow). The surfaces then ramp
  monotonically as roll damping fades.
- **The new roll starts with the same acceleration.** It then blends to the normal entry limit by the time it
  reaches half its target rate, so there is no step at zero.
- **Stops (target zero) are exactly as before.**

| Instant reversal | Roll-accel sag at zero, 1.7.2 / 1.7.3 / **1.7.4** | Wing surfaces pulled back toward neutral, 1.7.3 → **1.7.4** | Time to half the opposite rate, 1.7.2 / 1.7.3 / **1.7.4** |
|---|---|---|---|
| 90 m/s | 38 % / 10 % / **0 %** | 85 → 22 % of travel → **78 → 55 %** | 0.96 / 0.90 / **0.92 s** |
| 120 m/s | 31 % / 7 % / **0 %** | 79 → 23 % → **94 → 79 %** | 0.86 / 0.82 / **0.84 s** |
| 160 m/s | 35 % / 4 % / **0 %** | none | 0.78 / 0.74 / **0.76 s** |
| 220 m/s | 7 % / 2 % / **0 %** | none | 0.68 / 0.68 / **0.66 s** |
| 300 m/s | 1 % / 1 % / 1 % | none | 0.64 s (all) |

The remaining wing-surface drop at 90–120 m/s is a share shift to the stabs (they are cheaper for roll at low IAS),
not a change in roll acceleration: the roll acceleration stays flat through the reversal.

| Tried | Result |
|---|---|
| Constant 0.5 without carry-over | 0–5 % sag, but reversals 0.08–0.14 s slower |
| Constant 0.7 / 0.8 with carry-over | 0.06–0.14 s faster reversals, but roll-spam pitch disturbance ±2.6 / −2.7…+6.7 °/s at 100 m/s |
| **Constant 0.6 with carry-over (shipped)** | 0 %, reversal times within 0.02 s of 1.7.3, roll-spam pitch −1.0…+1.6 °/s (1.7.3: −1.1…+1.5) |

Regression: stops, overshoot and jerk (90–560 m/s), high-AoA rolls, pitch laws, protection, TVC takeover and the
60 s stress run are identical to 1.7.3. Stock-performance build: 0 % sag at all speeds, reversal 0.94 / 0.86 / 0.78 /
0.66 s.
