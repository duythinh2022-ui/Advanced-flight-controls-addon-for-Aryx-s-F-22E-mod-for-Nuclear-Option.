# F-22E Strike Raptor — FCS overhaul 1.2.0 (Nuclear Option)

Two builds of the same FCS code:

- **`Aryx_F22E_StrikeRaptor_FCS.dll` (52 KB, companion — the installed one).** FCS only, GUID
  `Aryx_F22E_StrikeRaptor.FCS`. Runs next to the **unmodified original `Aryx_F22E_StrikeRaptor_1_0_4.dll`**.
- `Aryx_F22E_StrikeRaptor_1.2.0_FCS.dll` (31 MB, all-in-one): original 1.0.4 classes (layout-verified identical)
  + byte-identical 1.0.4 bundle + FCS, GUID unchanged, version 1.2.0. Too big to transfer from here (limit
  20–30 MB), so it can be rebuilt from the source zip (`build.sh`) if you want a single file.

**Install (companion):** `BepInEx/plugins/` must contain the original 1.0.4 mod DLL plus
`Aryx_F22E_StrikeRaptor_FCS.dll`. **Remove** `Aryx_F22E_StrikeRaptor_1.1.2_FCS-test3.dll` (it carries its own
FCS hooks and the older 1.0.2 bundle). Never install the companion together with the all-in-one build.
Config: `BepInEx/config/Aryx_F22E_StrikeRaptor.FCS.cfg`.

## 1.2.1 fix (first in-game test)
First flight log: `expected 8 control surfaces, found 0` -> FCS never attached (stock controls; test3 failed the
same way). Cause: when complex physics starts, `AeroPart.CreateRB` calls `SetParent` and un-parents every part
into its own rigidbody object, so `aircraft.GetComponentsInChildren<>()` only sees the root part. Surfaces,
engines and gear are now collected by walking every part in `aircraft.partLookup` (+ `Aircraft.controlSurfaces`),
setup/attach retry instead of latching a failure, and the testbench now un-parents parts like the game
(negative control with the old search reproduces `found 0`). Roll-TVC removal and the effectiveness/servo
scaling were also silently skipped in the first build for the same reason.

## What it replaces
Stock `ControlsFilter.Filter` is skipped for the **player's** F-22E only (AI F-22s and every other aircraft
keep stock). Surfaces are driven individually (one deflection per surface injected into the game's
`ControlSurfaceFields` after `UpdateJobFields`), TVC through a transpiled `Turbofan.FixedUpdate`.

Airframe changes applied to every F-22E at spawn:
- Roll (and yaw) TVC removed: `thrustVectoring = (x, 0, 0)` — pitch-only nozzles (±10°).
- Flaperon + aileron aerodynamic effectiveness ×1.40, stabilator ×1.25 (lifting area scaled; travel unchanged).
- All servo rates ×1.30 (surfaces 70→91 °/s, TVC nozzle slew 70→91 °/s).

## Pitch law
| Condition | Law | Limits |
|---|---|---|
| Weight on wheels | direct (stick = fraction of available moment) | — |
| Gear down | rate command (stick × budget) | AoA +65/−45, G +9.5/−3.5 |
| Gear up, Stability Assist ON | AoA/G command blend | AoA +65/−45, G +9.5/−3.5 |
| Stability Assist OFF (MPO) | full rate command | no AoA limit, G +12.5/−3.5 |

- **Rate budget (max 48 °/s):** low AoA `max(5+0.15·IAS+40·T/W, (IAS−22)·1.1)`, high AoA `5+0.15·IAS+40·T/W`,
  blended over |AoA| 30→42° (your SP structure; T/W is live thrust / live mass).
- **AoA/G blend:** `betaG = clamp((G_avail − Gmax)/3 + 0.5)` where `G_avail = min(1 + q_budget·V/g, n_max_aero)`.
  `n_max_aero` comes from sweeping the whole airframe (all 37 aero parts, game equations, current q̄ and
  surface positions) through AoA 0–65° every 0.1 s. Stick maps AoA (×65/×45) and G (×8.5 / ×4.5) linearly.
- **Neutral stick = zero pitch-rate hold.** Easing the stick toward neutral on the same side = no nose shove:
  pitch rate decays at a feasible rate to 0, then AoA/G bleeds off along the flight path; the law re-captures
  when AoA reaches the new command. With no lift left (e.g. 60° at low speed) it just keeps holding zero rate.
- **Kinematic limiters (AoA and G):** `q ≤ q_meas − α̇_meas + min(√(2·a_brake·d), 3·d)` where `a_brake` is the
  *measured-now* braking acceleration available from the effector model (surfaces + TVC, from the allocator's
  moment tables). G margin is turned into AoA margin with the live lift slope; an extra feed-forward term
  holds load while decelerating. Reference is the *measured* flight-path rate, so roll coupling is included.
- **AoA protection:** beyond +65/−45 the nose is driven back at up to 48 °/s (not thrust/weight limited).
  Pulling (pushing) scales the recovery by (1 − stick); full stick holds AoA where it is.
- G loop bandwidth is normalized by lift slope (constant response from corner speed to the lift-curve edge).

## Lateral-directional law
- Stick commands **velocity-vector (stability-axis) roll**; body rates `p = pS·cosα − rS·sinα`, `r = pS·sinα + rS·cosα`.
- `rS` = sideslip regulation (2.5/s) + turn coordination (g·sinφ·cosθ/V). Rudders therefore aid every roll.
- Body roll ≤ 280 °/s (above 210 m/s the stock `(210/V)²` schedule, so roll performance matches stock),
  body yaw ≤ 65 °/s; limits enforced **jointly** (the p/r vector is scaled, never clipped per axis).
- Pedals below 36° AoA: sideslip command (15° full pedal). Above 36°: pedals blend into the same
  velocity-vector roll command as the stick (fully coupled at 50°).
- Velocity-vector roll is issued no faster than the measured roll *and* yaw authority can follow; a sideslip
  guard backs roll off above 5° of β error; allocator weights yaw over roll as AoA rises.
- Rolling-g limit: full roll rate to 6 g, 50 % at the G limit (keeps stab/TVC authority for the pitch axis).

## Inner loop and allocation
- INDI rate loops (pitch 5/s, roll 6/s, yaw 3.5/s): new effector moment = filtered current effector
  moment + I·(ω̇_des − ω̇_meas). Inertia tensor and CG are composed live from every part rigidbody.
- **Allocator:** each surface's moment is evaluated across its whole travel (~2° grid) with Nuclear Option's own
  aero equations at the surface's **own local AoA** (lift-normal transform, part velocity, airfoil chart,
  centre of lift). Damped Gauss–Newton joint solve over all 9 effectors, then an exhaustive 1-D sweep per
  effector. **Reversal logic falls out of the model:** a surface is never pushed past its C_L peak (35° local
  for these airfoils); a post-stall surface deflects the reversed way if that produces the needed moment;
  a small command that fits below stall uses the normal direction, a large one that would stall it does not.
- TVC is pitch-only and cost-weighted so aero surfaces are used first and TVC takes over as they run out.

## Verification (what was and was not done)
Done offline: the shipping FCS source was run unmodified against a Unity/game shim in a 6-DOF model built
from the F-22E's real part layout (masses, lift normals, areas, airfoils, centres of lift, surface servo
geometry, nozzle positions from the 1.0.4 bundle), with forces from Nuclear Option's AeroJob equations,
servos from ControlSurfaceJob_Math, and nozzles from Turbofan.FixedUpdate.

| Test | Result |
|---|---|
| Neutral stick 200 m/s | q 0.0–0.1 °/s |
| Full aft 90 m/s | AoA → 64.9 steady, no overshoot, q ≤ 48.0 |
| Full aft 230 / 300 m/s | 9.08 g (airframe limit at 230) / 9.29 g, no overshoot of 9.5 |
| Full forward 230 m/s | −3.67 g (limit −3.5, 5 % over) |
| Pull to 50°, ease to 30 % stick | holds 49.8°; then q→0, AoA bleeds 50→19.5°, no nose-down shove |
| MPO full aft 90 m/s | 48 °/s rate command through 65° and beyond |
| MPO past 120° AoA, assist ON | recovery at 46.7 °/s; full aft stick holds AoA instead |
| Full roll 220 m/s | 247–280 °/s, β within ±1.8° |
| Full roll at 45° AoA / pedal at 55° | mostly yaw (r > p), r ≤ 65, β ≤ 2° |
| Pedal 220 m/s | β −15° steady, no roll |
| 60 s random stick/pedal/assist toggling to 540 m/s | no NaN/divergence; ≈0.24 ms per step incl. sim |

**Known limits / not verified:**
- The sim is not the game: part rigidbodies are rigidly joined (game uses FixedJoints), inertia is
  point-mass based, no LERX/flap AoA-scheduled servos, no transonic effects on lift. **First flight is the real test.**
- A full-stick pitch reversal *combined with* a max-rate roll at ~190 m/s overshoots the 48 °/s budget
  to ~63 °/s for ~0.3 s (servo rate + inertial coupling). Pure pitch stays within +2 °/s.
- Rolling pulls at ~380 m/s overshot to ~10.2 g in the stress run (7 %).
- At 80–95 m/s and 45–55° AoA, yaw rate builds slowly (~35 °/s after 3 s): rudder authority only, no yaw TVC.
- Stick sign convention (NO `ControlInputs.pitch` +1 = nose down) was derived from the stock FlyByWire IL,
  not observed in game.

Telemetry: set `Telemetry = true` → 50 Hz CSV in the BepInEx folder (mode, IAS, AoA, β, n, rates,
commands, limiter state, envelope, TVC, every surface's command/position/local AoA).
