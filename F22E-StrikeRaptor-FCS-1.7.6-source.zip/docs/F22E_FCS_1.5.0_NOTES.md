# F-22E Strike Raptor FCS 1.5.0 (Nuclear Option)

1.5.0 is 1.4.0 plus an airframe re-balance toward relaxed stability. Install: plugins folder with the
unmodified 1.0.4 DLL plus `Aryx_F22E_StrikeRaptor_FCS.dll` (78 KB). `ConfigVersion` 5 resets
`StabilatorEffectiveness` to the new default once.

## Why
The effectiveness bumps I made in 1.3 (stabs ×1.30, flaperons ×1.50) scale lifting area. That makes the surfaces
work harder at neutral too, and both sit behind the CG, so the jet got much more pitch-stable than the original.
The neutral point moved from 0.20 m to 0.51 m aft of the CG. More trim deflection and more trim drag followed.

## Airframe changes (all F-22Es, AI included)
| | 1.0.4 original | 1.4 | **1.5** |
|---|---|---|---|
| Stabilator effectiveness | 1.00 | 1.30 | **1.10** (still above the original) |
| Flaperon / outer flaperon | 1.00 | 1.50 | 1.50 |
| LERX effectiveness (new) | 1.00 | 1.00 | **1.60** (lifting area of LERX_L/R) |
| CG shift (new) | 0 | 0 | **+0.05 m aft** (158 kg moved Fore → Back, total mass unchanged) |
| Static margin (neutral point aft of CG, 0–10° AoA) | 0.20 m | 0.51 m | **0.09 m** |
| Pitch moment to trim at 20° AoA, 100 m/s | −73 kNm | −198 kNm | **−39 kNm** |
| Nose-gear share of weight | 6 % | 6 % | 5 % |

The static margin is the same at 100 and 250 m/s (NO has no Mach effects), and stays 0.08 m at 10–30° AoA.
Measured in the sim with surfaces neutral and no thrust.

Why these numbers:
- **LERX 1.6, not 2.0.** At LERX ×1.75 the moment curve develops a nose-up break at 40–45° AoA: M goes from
  −29 to +4 kNm, a local pitch-up. At 1.6 it only flattens there (−58 → −30 kNm) and stays nose-down. At
  2.0 the whole airframe goes unstable (−0.06 m at LERX 2.0 even with stabs 1.0). The FCS could fly that, but AI
  F-22s and stock controls would get a pitch-up zone.
- **CG only 0.05 m.** The main gear axle is at z = −2.89 m and the CG was at −2.54, so 0.35 m ahead. Full fuel
  (tank centroid −2.68) moves the CG about 4 cm aft, and the jet sits on the mains with only 6 % of its weight
  on the nose wheel. At +0.05 m it is 5 % (0.30 m ahead of the mains, about 0.26 m with full fuel), so it will not
  sit on its tail. For reference, full-afterburner TVC at 10° nose-up at zero speed is already enough to lift the
  nose wheel with the stock CG, so treat pull-at-standstill the same as before. The mass-transfer method
  (`UnitPart.mass` and part rigidbody mass) is a real change to where the CG is, not a model trick.
- Config: `StabilatorEffectiveness`, `LERXEffectiveness`, `CGShiftAft`. For truly relaxed (slightly unstable):
  LERX about 1.8 or `CGShiftAft` 0.1 reaches −0.02 to −0.03 m, but the tail-sitting margin shrinks and the 40–45°
  pitch-up break appears.

## Effect in the sim (FCS on)
| | 1.4 | 1.5 |
|---|---|---|
| Trim at 21° / 160 m/s | stab 9–10° + TVC 10° | **stab 4.7° + TVC 1°** |
| Trim at 9.4 g / 300 m/s | stab 6°, TVC 9° | stab 3°, TVC −4° |
| AoA hold at 52° / 86 m/s | −1 to −3° | **−0.45…+0.16°** |
| Full aft 90 m/s | 61° | **64.9°** |
| Protection recovery from 77° (stick 0 / 0.5 / 1) | −12 / −6.6 / 0 °/s | **−36 / −20 / 0 °/s** |
| Hold 50° then ease to 20° | — | q 14 → 3 then eases back up, no overshoot |
| MPO full aft at 90 m/s | 68° max | goes all the way around (rate command, no AoA limit) |
| Roll 170–300 m/s (surfaces 71–98 %) | — | 186–292 °/s, stops within 0.5 s, β ≤ 2.3° |

Other additions in this build:
- **Inertial-coupling feed-forward** (`InertialCouplingFF`).
- **High-q pitch pacing** (`PitchOnsetLimit`): pitch-rate changes are paced by lift slope, which halved pitch
  tracking error in rolling pulls at 400+ m/s (12.5 → 5.8 °/s).

**Known limits:**
- **Rolling pulls at 400 m/s:** 9.77 g (limit 9.5, +3 %).
- **Supersonic:** above 450 m/s (M1.4+), rolling pulls and releases can hit −3 to −5 g. The sim has no
  transonic aero and the lift slope there is 3 g per degree.
- **Less natural stiffness:** with less static margin the FCS carries more of the pitch damping, so fast
  high-speed pitch transients are the area to watch in-game.

Everything else is as in the 1.4.0 notes.
