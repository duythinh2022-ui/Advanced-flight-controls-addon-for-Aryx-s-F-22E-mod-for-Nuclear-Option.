# F-22E Strike Raptor FCS 1.6.3 (Nuclear Option)

1.6.3 is 1.6.2 plus the fixes below. Install: replace `Aryx_F22E_StrikeRaptor_FCS.dll` (87 KB). `ConfigVersion` 8
resets three values to their new defaults once: `ActuatorDamping`, `MaxRollRate` and `RollLagCompensation`.

## Stabs / TVC felt slower (you were right)
The 1.6.2 damping was a 30 ms first-order lag. A lag delays everything by its time constant, including a steady
slew: a ramping command is followed 30 ms late the whole way, and the last few degrees creep in exponentially.

It is replaced by an **acceleration limit** on each servo command. The command reaches the servo's full speed in
`ActuatorDamping` seconds (now 0.04) and brakes into its target on a matching curve. There is also a 10 ms pre-filter
for step-to-step allocation noise. Servo speed is unchanged, a steady slew runs at full speed, and only the starts and
stops are rounded.

| 6-DOF bench | 1.6.2 (30 ms lag) | 1.6.3 |
|---|---|---|
| Pitch step, time to 63 % pitch rate, 250 / 400 m/s | 0.22 / 0.26 s | **0.20 / 0.24 s** |
| Roll step, time to 63 %, 250 / 400 m/s | 0.34 / 0.38 s | 0.34 / 0.36 s |
| Stab direction reversals, 140 / 250 / 400 m/s (4 s run) | 11 / 10 / 4 | 15 / 11 / 8 |

So it is faster than 1.6.2 and about as smooth. At 400 m/s the stabs make a few more small reversals.

## TVC stuck slightly negative after high-AoA manoeuvring (found, fixed)
**Cause: the control allocator's solver damping.** Stabs and nozzles can make the same pitch moment in many
combinations. The solver only drifted toward the preferred split at the rate its Levenberg damping allowed, which
was 5 % of each effector's own effectiveness². After a hard pull that left the nozzles at −4.7° with the stabs at
+0.9°, the two were fighting each other. The pair drifted back at only about 0.15 °/s.

**Fix:** the damping is now 0.1 %. The line search on the true nonlinear cost still guards every step.

| Recovered to level after a hard pull, 250 m/s | 1.6.2 | 1.6.3 |
|---|---|---|
| TVC / stabs, 3–12 s after release | −4.7 → −3.2° / +0.8° (slow drift) | **−0.02° / −0.01°** |
| Same condition without the pull | TVC +0.1°, stabs +0.1° | same |

## Roll rate at high IAS
- **`MaxRollRate` 420 → 280 °/s.** Below about 250 m/s IAS the original-aircraft schedule still sets the rate
  (117 / 152 / 200 / 238 / 258 °/s at 80–220 m/s TAS, 3 km). Above that it holds flat at 280.
- **The lag you felt was partly this, as you suspected.** At 560 m/s the jet now covers **83° of bank after
  release** (1.6.2: 170°), because it is stopping 280 °/s instead of 420.
- With the lower rate, `RollLagCompensation` is retuned 0.011 → 0.008:

| Roll release, 4 km | Rebound | Stop / commanded stop |
|---|---|---|
| 90–160 m/s | ≤ 1.5 °/s | 0.60–0.64 / 0.56–0.66 s |
| 220–560 m/s | ≤ 1.1 °/s | 0.54–0.56 / 0.52–0.56 s |

## Nose rocking in fast rolls: not reproduced beyond ±2–3 °/s
In the bench a 280 °/s roll at 300–450 m/s shows the nose yawing ±2–3 °/s, with sideslip under 1°. That is the
kinematics of a velocity-vector roll: the body yaw needed is p·sin(AoA), and AoA wanders ±0.6° between upright and
inverted at zero pitch rate, plus gravity's sideslip term. I tried two changes:
- **Body-axis roll at high IAS / low AoA:** it only took the peak from 2.9 to 2.8 °/s, and it pushed a 400 m/s full
  rolling pull to **10.7 g**, so it is not in this build.
- **A stiffer yaw loop at high IAS:** it gave −0.3 °/s, so it is not in this build either.

If what you see in game is bigger than ±3 °/s, record it:
1. Set `Telemetry = true`.
2. Do a couple of fast rolls.
3. Send me the `BepInEx/F22E_FCS_*.csv`. It has p, r, rCmd, β and AoA at 50 Hz, which is what I need to find it.

## Regression (1.6.2 → 1.6.3)
| Test | 1.6.2 | 1.6.3 |
|---|---|---|
| Rolling pull 250 / 400 m/s, full aft + roll (limit 9.5 g) | 9.42 / 9.55 g | 9.46 / 9.54 g |
| Random stress, worst assisted-mode load below 450 m/s (excl. the test's MPO→assist flip at 12 g) | 9.80 g (measured on 1.6.1) | **9.96 g** |
| Rudder sweep (β during rolls) | ≤ ±1.5° | ≤ ±1.5° |
| Stick reversal at 190 m/s, peak nose-down rate (budget 48) | −24 °/s | −37 °/s. It comes from the allocator fix (−24.6 with the old solver damping). Worst tracking error is unchanged at −16 °/s, so the jet is following its command, not overshooting it. |
| AoA hold, protection, MPO, unload, pedal | — | within 0.3° of AoA / 1 °/s |
| 60 s stress | no NaN | no NaN, 0.24 ms per step |

The countermeasure changes from 1.6.2 are unchanged and still unverified in game. Check the log line
`F-22E countermeasures on …`.
