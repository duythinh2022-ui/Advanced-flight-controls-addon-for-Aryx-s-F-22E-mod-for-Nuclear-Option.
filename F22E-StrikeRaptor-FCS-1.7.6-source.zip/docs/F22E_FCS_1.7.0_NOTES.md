# F-22E Strike Raptor FCS 1.7.0 (Nuclear Option)

1.7.0 is 1.6.5 (normal pitch allocation, not the stab-primary experiment) plus the changes below. It now ships in two
builds that share every control law:

| Build | DLL | Config file | Thrust | Parasitic drag | Flares | EW storage / recharge |
|---|---|---|---|---|---|---|
| **Buffed** | `Aryx_F22E_StrikeRaptor_FCS.dll` | `Aryx_F22E_StrikeRaptor.FCS.cfg` | ×1.08 | ×0.885 | ×10 | ×1.5 / ×1.2 |
| **Stock performance** | `Aryx_F22E_StrikeRaptor_FCS_StockPerf.dll` | `Aryx_F22E_StrikeRaptor.FCS.StockPerf.cfg` | ×1 | ×1 | ×1 | ×1 / ×1 (not touched at all) |

Both keep the aero/control tweaks: flaperon ×1.5, stabilator ×1.1, LERX ×1.6, CG +0.05 m aft, servos ×1.3, pitch-only
TVC. Both builds use the same plugin GUID, so BepInEx loads only one; install exactly one of them. The stock build
has its own config file so the two sets of defaults never mix. `ConfigVersion` 10 resets `LowIasYawBoost` once
(its meaning changed, see below) and adds two keys.

Everything below is from the 6-DOF bench (the game's aero equations on the F-22E part layout). None of it has been
flown in game yet.

## 1. Yaw-rate margin at low IAS: now a curve
1.6.5 applied the full ×1.35 margin everywhere below 120 m/s IAS, fading linearly to ×1 by 180 m/s. You were right
that this was the wrong shape. In the 55–85 m/s IAS band (200–300 km/h) the wider cap barely raised the peak rate,
because the yaw axis is authority-limited there. What it did do was let the roll command run up to a rate the jet
then needed longer to stop.

**New shape:** full `LowIasYawBoost` (1.35) at or below `LowIasYawBoostFullIAS` (48 m/s ≈ 175 km/h). Above that it
decays exponentially with a scale of `LowIasYawBoostFalloff` (10 m/s):

| IAS | 40 m/s | 48 | 55 (200 km/h) | 60 | 70 (250 km/h) | 83 (300 km/h) | ≥100 |
|---|---|---|---|---|---|---|---|
| 1.6.5 margin | ×1.35 | ×1.35 | ×1.35 | ×1.35 | ×1.35 | ×1.35 | ×1.35 → 1 at 180 |
| **1.7.0 margin** | ×1.35 | ×1.35 | ×1.17 | ×1.10 | ×1.04 | ×1.01 | ×1.00 |

I chose the breakpoint from a sweep of the full-aft falling leaf and of full-stick rolls at 38–48° AoA. A breakpoint
of 40 m/s cost falling-leaf yaw (22.8 °/s). Going above ×1.35 at the low end is authority-limited: ×2.0 gives only
27.6–32.7 °/s, and the yaw rate left after pedal release rises from 7–8 to 12–20 °/s.

## 2. High-AoA roll responsiveness (the "peak then lag" part)
Tracing a 38° AoA roll at 75–90 m/s IAS showed two separate things:
- **The yaw loop was running on only 50 % feed-forward.** `YawRateFeedForward` 0.5 was set in 1.6.1 to calm the
  rudders at *low* AoA. At moderate and high AoA the body yaw *is* the velocity-vector roll, so halving its lead made
  the roll trail its command. The yaw feed-forward now blends to 100 % between 15° and 28° AoA (below 15° it is
  unchanged).
- **The rest of the lag is authority.** At 38–40° AoA, 75–90 m/s IAS, the allocator delivers about half the
  demanded yaw moment. One stab sits at −30° (full travel). The other is near its own stall at +6°. The rudders
  are fading (35→50° AoA). TVC is pitch-only, so nothing else can yaw. I also tried a "leash" that holds the roll
  command within a few °/s of the jet's actual rate. It changed stop times by ≤0.02 s, so it is not in the build.

| Full-stick roll, then release (3 km) | 1.6.5 stop / bank after release | **1.7.0** | peak rate 1.6.5 → 1.7.0 | sideslip 1.6.5 → 1.7.0 |
|---|---|---|---|---|
| 25° AoA, 83–110 m/s IAS | 1.16–1.32 s / 36–40° | **0.92–1.16 s** / 39–41° | 68–78 → 65–77 | ±8–10 → **−8…+6°** |
| 28° AoA, 105–124 IAS | 1.28 s / 40° | **1.00 s** / 45° | 72 → 78 | −9.7…+7.7 → **−7.9…+2.9°** |
| 38° AoA, 65–100 IAS | 1.78–1.92 s / 35–55° | **1.52–1.62 s** / 29–46° | 29–49 → 31–51 | ±2 (both) |
| 47–48° AoA, 56–89 IAS | 1.86–1.94 s / 34–42° | **1.48–1.68 s** / 26–29° | 27–39 → 26–35 | −1.5…+3 → **−0.8…+1.5°** |

Stop = the jet's velocity-vector rate below 3 °/s after the stick is released. At 47° AoA the peak is 2–4 °/s lower
than 1.6.5. That is the rate you described as the lag, traded for a stop 0.3–0.4 s sooner.

**Falling leaf** (full aft, pedal reversals, 36–58 m/s IAS): max yaw rate is 24.5 / 25.6 °/s. 1.6.5 gave
24.2 / 26.1 and 1.6.4 gave 20.1 / 22.0.

## 3. AoA-protection override: nose shove (found two causes, both fixed)
New test: MPO pull past the limit, Stability Assist back on with full aft held, then hold for 10 s. It covers
90/130/170 m/s, AB and idle, and switching at 55–121° AoA.
- **AoA passing 180° (tail slide).** AoA is atan2-based, so +179° becomes −179° one frame later. The FCS read that
  as a −45° limit violation, and the negative-side protection ignores the aft stick, so it drove the nose at
  −48 °/s: a −25 °/s shove. Protection now uses AoA unwrapped through ±180° (back to plain AoA below 90°), so it
  stays on the side it was on.
- **AoA falling back through the limit.** While the jet sinks with the nose held, AoA can fall back below 65°. The
  hold then ended and the normal AoA law (full aft = 65°) chased the falling flight path at up to 48 °/s at
  16 m/s IAS. **The override is now latched:** it arms when the stick is held fully against a protection that was
  entered at least 5° past the limit (MPO / departure), and it holds zero pitch rate until the stick is eased below
  90 %. Easing the stick hands back to the normal law. Small overshoots at the AoA limit (<5°) during ordinary
  full-aft pulls do not arm it.

| Override hold, AB (6 cases) | 1.6.5 pitch rate after capture | **1.7.0** |
|---|---|---|
| Switch at 69–121° AoA | 0 … +48 °/s, and −25.6 °/s at the 180° wrap | **−0.3 … +0.5 °/s** |

At idle thrust the nose still sags up to −11.8 °/s at 55–80° AoA. The law commands zero there, but the pitch-up
authority is not enough (idle TVC, low q̄).

## 4. TVC going negative when rolling at low IAS / low AoA: explained, not changed
Reproduced: at 100 m/s TAS / 6° AoA the nozzles go from +4.0° to −4.0° during a full roll, while the pitch rate
stays within ±0.4 °/s. Per-surface pitch moments show why. The roll deflections are not pitch-neutral: the
differential stabs (−9°/+13°), the flaperons and the ailerons sit on nonlinear parts of their curves, and together
they add **+71 kNm** of pitch moment. The allocator cancels that with the cheapest effector, which is the nozzles
(−107 kNm swing). About 1° of the swing is ordinary trim change, as AoA falls from 6° to −2° in the roll. So the
nozzles are doing correct trim work, not sticking.

Making the stabs take it is a cost-weight change. `TvcMoveCost` 0.02 halves the swing (−1.9° at 100 m/s), but that is
the stab-primary setting you found no better, and it brought the regressions listed in the 1.6.5 StabPrimary notes.
I left it alone. If you want the swing gone without touching pitch feel, I can raise the nozzle move cost only
while rolling at attached flow.

## 5. Original thrust / drag (stock-performance build): no law retune needed
The FCS measures its authorities live: TVC moment from live nozzle thrust, pitch accel up/down, roll/yaw authority,
T/W for the pitch budget and envelope. So it re-schedules itself with thrust and drag. Full regression, same
bench, buffed vs stock performance:

| Test | Buffed | Stock perf |
|---|---|---|
| Full aft 90 m/s (AoA limit 65) | 64.9° | 64.9° |
| 230 m/s pull (limit 9.5 g) | 9.22 g | 9.20 g |
| Protection recovery from 77°, stick 0 | −46.6 °/s | −47.1 °/s |
| AoA hold overshoot, 5 cases | 0.17–0.64° | 0.18–0.76° |
| Roll steady 80–300 m/s TAS | 117 / 152 / 200 / 238 / 250 | 114 / 148 / 196 / 235 / 250 |
| Roll stop 90–560 m/s | 0.50–0.64 s | 0.50–0.66 s |
| Rolling pull 250 / 400 m/s | 9.46 / 9.66 g | 9.43 / 9.64 g |
| 60 s random stress | no NaN, 0.27 ms/step | no NaN, 0.28 ms/step |

The differences are 1–3 %. That is the lower TVC moment (−7 % thrust) and the lower energy, not a law mismatch, so
the stock build uses the same gains. What changes in the air is energy: less excess thrust and more drag mean you
bleed speed faster in sustained high-AoA work.

## Regression (1.6.5 → 1.7.0, buffed)
| Test | 1.6.5 | 1.7.0 |
|---|---|---|
| Rolling pull at the AoA limit, 170 m/s (full aft + roll) | peak AoA 65.0° | **67.2°**. Full yaw feed-forward at 55–65° AoA competes with pitch; protection catches it (q → 0), then AoA dips to 59° and recaptures. Fading the feed-forward out above 45° did not remove it and lost the pedal@55° improvement below. |
| AoA hold after a roll, 5 cases, overshoot | 0.17–0.42° | 0.17–0.64° |
| Pedal at 55° AoA, sideslip | 0…+2.7° | **−0.5…+1.0°** |
| Roll at 45° AoA, 90 m/s | p ≤ 23, r ≤ 26.9, β 0…1.5 | p ≤ 21, r ≤ 24.1, β −1.1…0.8 |
| Roll step 140 m/s, time to 63 % | 0.48 s | 0.50 s |
| Everything else (pitch, G limits, MPO, protection recovery, roll stops, rudder sweep, TVC after recovery) | — | unchanged within 0.3° AoA / 0.2 g / 1 °/s |

## Config
| Key | Default | Note |
|---|---|---|
| `LowIasYawBoost` | 1.35 | reset once by ConfigVersion 10 (meaning changed: it is now the maximum, at the lowest IAS) |
| `LowIasYawBoostFullIAS` | 48 m/s | new |
| `LowIasYawBoostFalloff` | 10 m/s | new |
| `YawRateFeedForward` | 0.5 | unchanged value; now only applies below 15° AoA (100 % by 28°) |
| `ThrustScale`, `ParasiticDragScale`, `FlareCountScale`, `EWCapacityScale`, `EWRechargeScale` | build-dependent | see the table at the top |

The override latch and AoA unwrap have no keys.
