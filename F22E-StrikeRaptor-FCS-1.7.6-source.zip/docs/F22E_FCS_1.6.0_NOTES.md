# F-22E Strike Raptor FCS 1.6.0 (Nuclear Option)

1.6.0 is 1.5.0 plus the changes below. Install: `Aryx_F22E_StrikeRaptor_FCS.dll` (81 KB) next to the unmodified
1.0.4 DLL. `ConfigVersion` 6 resets `SideslipGain` and `YawRateGain` to their new defaults once.

## Changes
| Your report | Change | Sim result (6-DOF bench) |
|---|---|---|
| Low-IAS / low-AoA roll: stabs lazy, flaperons do the work | Differential-stab roll cost 1e-2 → **3e-3** below 160 m/s IAS, blending back to 1e-2 by 240 m/s so high-speed pitch keeps its stabs. The share of stab roll counted in the roll ceiling goes 0.25 → 0.45 over the same range (`StabilatorRollCost`, `StabilatorRollShare`). | Steady roll rate at 3 km: 95 m/s TAS 90 → **117 °/s**; 115 m/s 117 → **153**; 150 m/s 152 → **198**; 185 m/s 186 → **236**. β stays within ±1.3° at up to about 115 m/s TAS and ±2.7° at 150. A 1.8 m/s² trial (cost 5e-4) gave more rate but −12 °/s pitch kicks and −30 °/s stop rebounds, so it was rejected. |
| Nose wobbles when spamming roll left/right | Rudder/yaw loop was underdamped against the wing surfaces' adverse yaw. `SideslipGain` 2.0 → **1.3**, `YawRateGain` 3.5 → **2.5**. | Roll spam (±full every 0.6 s): β −4.7…+3.8 → **−2.8…+3.2** at 100 m/s and −3.0…+3.4 → **−0.4…+2.8** at 140. The pedal sideslip response is a bit softer: −11…−13.6° in the first 1.5 s instead of −13…−14.4°. |
| Moderate-AoA roll not responsive | Body yaw-rate cap above 15–25° AoA: 0.45 → **0.70 × measured yaw authority** (`YawStopFactor`). | Full roll at 29° AoA, 120 m/s: p 38 → **54 °/s**, r 26 → 36 °/s. β on the stop is now ±6.6° (was ±3.5). |
| "Only one stab moves at moderate AoA" | Not changed: this is what the aero model gives. At 29° AoA the stab going down for the roll sits at its own local AoA of ~34°, right at its C_L peak, so more deflection only stalls it. The other stab does the roll by giving up lift, and it goes to +25–29°. The roll at that condition is limited by the rudders, which sit at ±28° full travel, not by the stabs. Past the stall both stabs are in the reversed region, which is why they look active again there. | — |
| Outer flaperons don't work as flaps | Outer flaperons now droop with the flap schedule: 60 % of the inboard flap angle (`OuterFlaperonDroop`). They are stall-capped on their own local AoA with 18° × roll-stick headroom, and TE-up load relief is subtracted on top. | 111 m/s at 13° AoA: inboard 14.6°, **outer 10.5°**; both retract to 0 with full roll stick. 218 m/s: inboard 5.1°, outer 3.1°. |
| Actuator damping | A first-order lag (**20 ms**, `ActuatorDamping`) between the allocator and every servo, surfaces and nozzles. Servo rate limits are unchanged. | This also cut the rolling-pull overshoot at 400 m/s: 10.82 g without it, **9.83 g** with 20 ms (30 ms gave 9.98). |
| Stick smoothing like SimplePlanes | First-order smoothing on pitch, roll and pedal inputs (**60 ms**, `StickSmoothing`), before the existing rate limits. | AoA hold still within −0.56…+0.2° in all five cases. |

## Unchanged known limits
- **Rolling pull at about 415 m/s:** up to 9.98 g in the random stress run (+5 %).
- **Supersonic:** above 450 m/s the load-factor exceedances remain. The bench has no transonic aero.
- **Low-IAS roll:** still somewhat below stock ×1.2 (see the 1.4 notes). The stab change closed most of the gap:
  117 of 177 at 95 m/s TAS, 198 of 221 at 150.
