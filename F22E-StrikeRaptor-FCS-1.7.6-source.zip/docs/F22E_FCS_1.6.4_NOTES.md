# F-22E Strike Raptor FCS 1.6.4 (Nuclear Option)

1.6.4 is 1.6.3 with two limits changed. Install: replace `Aryx_F22E_StrikeRaptor_FCS.dll`. `ConfigVersion` 9 sets
both new defaults once.

| | 1.6.3 | 1.6.4 | Config |
|---|---|---|---|
| Roll-rate ceiling | 280 °/s | **250 °/s** | `MaxRollRate` |
| Body yaw-rate limit | 65 °/s | **75 °/s** | `MaxYawRate` |

## Where the new roll ceiling bites (6-DOF bench)
The cap binds wherever the original-aircraft schedule would exceed 250 °/s. That schedule scales with true
airspeed, so where it binds depends on altitude:
- **3 km:** from about 215 m/s IAS. Below that nothing changes (117 / 152 / 200 / 238 °/s at 80–170 m/s TAS).
- **8 km:** from about 180 m/s IAS. At 250 m/s TAS (185 IAS) the rate was 273 °/s and is now 250.

| Roll release, 4 km | 1.6.3 | 1.6.4 |
|---|---|---|
| 220 m/s: rate / bank after release / rebound | 265 °/s / 83° / −1.1 °/s | 250 / **77°** / −0.4 |
| 300–560 m/s | 280 °/s / 82–84° / ≤ 0.2 | 250 / **69–70°** / ≤ 0.2 |
| Stop vs commanded stop | 0.54–0.56 / 0.52–0.56 s | 0.50–0.52 / 0.50 s |

## Where the yaw limit matters
The 75 °/s limit only applies when nothing lower binds. Above 15–25° AoA the yaw rate is still capped at
0.7 × measured yaw authority (`YawStopFactor`), so the jet can always stop the yaw again. In the bench's
high-AoA roll tests that authority cap is what sets r (35–37 °/s), so those results are unchanged. The higher
limit shows up only in low-AoA, high-authority cases, e.g. pedal inputs at speed and velocity-vector rolls where
authority allows more.

## Regression
| Test | 1.6.3 | 1.6.4 |
|---|---|---|
| Rolling pull 250 / 400 m/s (limit 9.5 g) | 9.46 / 9.54 g | 9.46 / 9.66 g |
| Rolling pull 400 m/s at 0.63 stick | 6.91 g | 6.91 g |
| Random stress, assisted-mode positive-g exceedances below 450 m/s | 9.96 g peak | **none** |
| Rudder sweep, yaw rate during 300–450 m/s rolls | ≤ 2.9 °/s | ≤ 2.9 °/s |
| Pitch, AoA hold, protection, MPO, pedal, flaps | — | unchanged |
| 60 s stress | no NaN | no NaN |

The 400 m/s full-aft rolling pull peaks at 9.66 g (+1.7 %). The lower roll rate makes the rolling-g limiter's
extra lead (which scales with roll rate) a little smaller there. Everything else is as in the 1.6.3 notes.
