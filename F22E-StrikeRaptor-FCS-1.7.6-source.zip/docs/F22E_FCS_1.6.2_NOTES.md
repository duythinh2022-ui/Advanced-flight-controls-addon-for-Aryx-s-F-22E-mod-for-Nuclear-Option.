# F-22E Strike Raptor FCS 1.6.2 (Nuclear Option)

1.6.2 is 1.6.1 plus a roll-stop fix, 30 ms actuator damping, and countermeasure changes. Install: replace
`Aryx_F22E_StrikeRaptor_FCS.dll` (86 KB). `ConfigVersion` 7 resets `ActuatorDamping` to the new 0.03 once. New keys
are added with their defaults.

## Roll stop after releasing the stick
### What was wrong
I added a roll-release test at 90–560 m/s TAS, 4 km altitude. It releases the stick after a full-stick roll and
measures the stop. It showed the same three things you described.

- **Low IAS: small drift, then an overcorrection.** The stop was planned with a constant deceleration taken from the
  total roll authority, which counts part of the differential stabs. The stabs are costed for pitch and barely help
  roll, so the wing surfaces ran to full opposite travel (flaperons 14°, ailerons 20°) to follow the plan. Roll
  damping falls away as the rate falls, so at the end of the stop they were still at full deflection. They then had
  to unwind at servo rate (~91 °/s) after the command had already ended. That kept decelerating the jet past zero:
  −9 to −10 °/s rebound.
- **Supersonic: lag.** Roll damping grows with dynamic pressure. The inner loop (INDI) only sees the damping moment
  fall as the rate falls after its 40 ms sync filter catches up, so the jet trailed the command. It was still at
  about 20 °/s when the command reached zero, and the rest decayed on roll damping alone: 1.2–1.5 s to stop against
  0.6–0.7 s commanded, with 170–200° of bank after release at 480–560 m/s.
- **In between: a jerk.** The braking curve ended with a one-step jump in commanded acceleration, because the
  continuous √(2J·e) curve does not land exactly at 50 Hz.

### Changes
| | 1.6.1 | 1.6.2 | Config |
|---|---|---|---|
| Braking deceleration budget | 0.8 × total roll authority (incl. stab share), constant | 0.8 × **wing-surface** authority **+ roll damping at the present rate**. It tapers as the rate falls, so the surfaces are near neutral when the roll stops. | `RollBrakeUse` (unchanged) |
| Roll command lead | none | 0.011 s per 1/s of roll damping above 2.5/s: 0 at low IAS, ~0.035 s at 300 m/s, ~0.08 s at 560 m/s | `RollLagCompensation` |
| Braking curve end | continuous √(2J·e), last-step snap | discrete-time curve, lands exactly | — |
| Roll jerk | A / 0.18 s | also ≤ what the roll surfaces can slew (half travel per 0.22 s) | — |
| Actuator damping | 20 ms | **30 ms** | `ActuatorDamping` |

### Sim results (full-stick roll, release, 4 km, 1.6.1 → 1.6.2)
Stop is when |p| < 3 °/s. Commanded stop is when the shaped command reaches zero.

| TAS | p at release | Rebound past zero | Time to stop (commanded) | Bank after release |
|---|---|---|---|---|
| 90 m/s | 106 | −9.3 → **−2.9 °/s** | 0.58 → 0.64 s (0.66) | 36 → 39° |
| 120 | 155 | −10.4 → **−3.2** | 0.56 → 0.60 (0.60) | 50 → 52° |
| 160 | 223 | −9.5 → **−2.7** | 0.56 → 0.58 (0.56) | 73 → 73° |
| 220 | 264 | 0.1 → −4.3 | 0.58 → **0.54** (0.52) | 87 → 85° |
| 300 | 292 | 0.0 → −4.3 | 0.96 → **0.56** (0.56) | 98 → **91°** |
| 400 | 349 | 0.2 → −2.7 | 1.20 → **0.64** (0.64) | 137 → **123°** |
| 480 | 395 | 0.4 → −0.5 | 1.38 → **0.72** (0.70) | 172 → **152°** |
| 560 | 420 | 0.7 → 0.4 | 1.50 → **0.76** (0.74) | 196 → **170°** |

The jet now stops when the command does at every speed, and the rebound is ≤ 4.3 °/s everywhere. That is about
0.1° of bank.

**Not fixed: the ~0.18–0.22 s before the roll rate visibly drops (10 %).** This comes from the surfaces having to
swing from the rolling deflection to the braking one at servo rate: 20–30° at ~91 °/s, plus the stick smoothing you
asked for. Raising the stick slew limit from 10/s to 20/s changed it by 0–0.02 s, so I left it.

**Cost:** roll spam at 100 m/s is a little slower, −86…+80 → −76…+73 °/s, because reversals now plan on the
wing-surface authority. Steady roll rates are unchanged: 117 / 153 / 199 / 238 / 256 / 295 °/s at 80–300 m/s TAS.

### Regression (everything else)
Pitch, AoA hold, protection, MPO, unload, rudder sweep and flap tests are unchanged within 0.3° of AoA and 2 °/s of pitch rate.

| Test | 1.6.1 | 1.6.2 |
|---|---|---|
| Rolling pull 250 / 400 m/s | 9.44 / 9.57 g | 9.42 / 9.55 g |
| 560 m/s rolling pull | 8.80 g | 9.09 g |
| 60 s stress | no NaN | no NaN, 0.24 ms per step |

## Countermeasures (every F-22E, AI included, applied at spawn)
| | Config | Default | What it scales |
|---|---|---|---|
| Flares | `FlareCountScale` | ×10 | `FlareEjector` capacity (`maxAmmo`) and the load at spawn; rearming refills to the new capacity |
| EW capacity | `EWCapacityScale` | ×1.5 | the aircraft `PowerSupply` storage (`maxCharge`), which is where the radar jammer's capacitance goes. Capacitance added later (a jammer attaching after spawn) is scaled too, via a patch on `PowerSupply.ModifyCapacitance`. |
| EW recharge | `EWRechargeScale` | ×1.2 | `PowerSupply.chargePerRPM` (engine-driven charging) |

- The jammer's draw per activation (`powerUsage`) and its intensity are untouched, so the extra storage means
  1.5× the jamming time from a full charge.
- A supply that was full at setup stays full.
- The log prints one line per aircraft with the before and after flare and EW values:
  `F-22E countermeasures on …`.

**Verification limit:** the game's own logic (flare ejector, jammer, power supply) is not in my bench, so none of
this has been exercised. What I checked against `Assembly-CSharp.dll`:
- every field (`ammo`, `maxAmmo`, `charge`, `maxCharge`, `chargePerRPM`) exists with the type the code expects;
- every method the code calls (`GetPowerSupply`, `UpdateHUD`, `IsLocalAircraft`, `ModifyCapacitance(float capacitance)`)
  is public with the expected signature;
- the DLL builds.

In multiplayer the host's values may override the client's flare count. I only looked at single-player code paths.

Everything else is as in the 1.6.1 notes.
